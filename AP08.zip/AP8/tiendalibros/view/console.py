import sys

from tiendalibros.modelo.tienda_libros import TiendaLibros


class UIConsola:

    def __init__(self):
        self.tienda_libros: TiendaLibros = TiendaLibros()
        self.opciones = {
            "1": self.adicionar_un_libro_a_catalogo,
            "2": self.agregar_libro_a_carrito_de_compras,
            "3": self.retirar_libro_de_carrito_de_compras,
            "4": self.salir
        }

    @staticmethod
    def salir():
        print("\nGRACIAS POR VISITAR NUESTRA TIENDA DE LIBROS. VUELVA PRONTO")
        sys.exit(0)

    @staticmethod
    def mostrar_menu():
        titulo = "¡Tienda Libros!"
        print(f"\n{titulo:_^30}")
        print("1. Adicionar un libro al catálogo")
        print("2. Agregar libro a carrito de compras")
        print("3. Retirar libro de carrito de compras")
        print(f"{'_':_^30}")

    def ejecutar_app(self):
        while True:
            self.mostrar_menu()
            opcion = input("Seleccione una opción: ")
            accion = self.opciones.get(opcion)
            if accion:
                accion()
            else:
                print(f"{opcion} no es una opción válida")

    def retirar_libro_de_carrito_de_compras(self, tienda_libros: TiendaLibros):
        isbn_libro_a_retirar = input("Ingrese el ISBN del libro que desea retirar: ")

        try:
            tienda_libros.retirar_item_de_carrito(isbn_libro_a_retirar)
            print("Libro retirado del carrito con éxito")
        except ValueError as e:
            print(f"Error: {e}")

    def agregar_libro_a_carrito_de_compras(self, tienda_libros: TiendaLibros):
        while True:
            try:
                isbn_libro = input("Ingrese el ISBN del libro que desea agregar: ")
                cantidad_unidades = int(input("Ingrese la cantidad de unidades: "))

                libro = tienda_libros.catalogo.buscar_libro_por_isbn(isbn_libro)
                item_compra = tienda_libros.agregar_libro_a_carrito(libro, cantidad_unidades)

                print(f"Libro agregado al carrito: {item_compra}")
                break

            except ValueError as e:
                print(f"Error: {e}")
            except LibroAgotadoError as e:
                print(f"Error: {e}")
            except ExistenciasInsuficientesError as e:
                print(f"Error: {e}")
 
    def adicionar_un_libro_a_catalogo(self, tienda_libros: TiendaLibros):
        while True:
            try:
                isbn = input("Ingrese el ISBN del libro: ")
                titulo = input("Ingrese el título del libro: ")
                precio = float(input("Ingrese el precio del libro: "))
                existencias = int(input("Ingrese las existencias del libro: "))

                tienda_libros.catalogo.adicionar_libro_a_catalogo(
                    Libro(isbn, titulo, precio, existencias)
                )
                print("Libro agregado al catálogo con éxito")
                break

            except ValueError as e:
                print(f"Error de entrada: {e}")
            except ISBNInvalidoError as e:
                print(f"Error: {e}")