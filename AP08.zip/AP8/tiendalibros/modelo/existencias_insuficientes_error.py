from tiendalibros.modelo.libro_error import LibroError


class ExistenciasInsuficientesError(LibroError):
    pass

    # Defina metodo inicializador
    def __init__(self, mensaje, cantidad_a_comprar: int):
        super().__init__(mensaje)
        self.cantidad_a_comprar = cantidad_a_comprar
    # Defina metodo espcial
    def __str__(self):
        return f"El libro con título '{self.mensaje.titulo}' y ISBN: '{self.mensaje.isbn}' no tiene suficientes existencias para realizar la compra: cantidad a comprar: {self.cantidad_a_comprar}, existencias: {self.mensaje.existencias}"
