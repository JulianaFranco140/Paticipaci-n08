class ItemCompra:
    def __init__(self, libro: Libro, cantidad: int):
        self.libro = libro
        self.cantidad = cantidad

    def get_precio_total(self) -> float:
        return self.libro.precio * self.cantidad

    def __str__(self) -> str:
        return f"Libro: {self.libro.nombre} - Cantidad: {self.cantidad}"

    def calcular_subtotal(self) -> float:
        subtotal = self.cantidad * self.libro.precio
        return subtotal