class CarroCompras:
    
    def __init__(self):
        self.items = []

    def agregar_item(self, item_compra: ItemCompra):
        self.items.append(item_compra)

    def quitar_item(self, item_compra: ItemCompra):
        if item_compra in self.items:
            self.items.remove(item_compra)

    def calcular_total(self) -> float:
        total = 0
        for item in self.items:
            total += item.get_precio_total()
        return total

    def mostrar_carro(self):
        print("**Contenido del carro de compras:**")
        for item in self.items:
            print(f"- {item}")
        print(f"**Total:** {self.calcular_total()}")

