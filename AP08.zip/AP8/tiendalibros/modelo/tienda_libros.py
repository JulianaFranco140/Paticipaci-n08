class TiendaLibros:


    def __init__(self):
        self.catalogo = {}
        self.carrito = CarroCompras()

    def buscar_libro_por_isbn(self, isbn: str) -> Libro:
        if isbn in self.catalogo:
            return self.catalogo[isbn]
        else:
            raise ValueError(f"No se encontró el libro con ISBN: {isbn}")

    def mostrar_catalogo(self):
        print("**Catálogo de libros:**")
        for libro in self.catalogo.values():
            print(f"- {libro}")

    def agregar_item_al_carro(self, isbn: str, cantidad: int):
        libro = self.buscar_libro_por_isbn(isbn)
        item_compra = self.carrito.agregar_item(libro, cantidad)
        return item_compra

    def mostrar_carro(self):
        self.carrito.mostrar_carro()

    def procesar_compra(self):
        total = self.carrito.calcular_total()
        print(f"**Total de la compra:** {total}")
        # Implementar lógica de pago (si es necesario)
        print("**Compra procesada exitosamente!")
        self.carrito.items = []  # Vaciar el carrito después de la compra

    def adicionar_libro_a_catalogo(self, isbn: str, titulo: str, precio: float, existencias: int) -> Libro:
        if isbn in self.catalogo:
            raise LibroExistenteError(MensajeLibro(titulo, isbn))  # Raise exception if book exists

        libro = Libro(isbn, titulo, precio, existencias)
        self.catalogo[isbn] = libro
        return libro

    def agregar_libro_a_carrito(self, libro: Libro, cantidad_unidades: int) -> ItemCompra:
        if libro.existencias == 0:
            raise LibroAgotadoError(MensajeLibro(libro.titulo, libro.isbn))

        if cantidad_unidades > libro.existencias:
            raise ExistenciasInsuficientesError(
                MensajeLibro(libro.titulo, libro.isbn), cantidad_unidades
            )

        libro.existencias -= cantidad_unidades
        item_compra = ItemCompra(libro, cantidad_unidades)
        self.carrito.append(item_compra)
        return item_compra
        
    def retirar_item_de_carrito(self, isbn: str) -> None:
        self.carrito.quitar_item(isbn)